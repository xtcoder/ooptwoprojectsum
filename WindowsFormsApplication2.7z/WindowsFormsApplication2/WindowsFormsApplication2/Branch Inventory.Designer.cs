﻿namespace WindowsFormsApplication2
{
    partial class Branch_Inventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ShowallButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.BranchIDlabel13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.BranchcomboBox1 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.ProductnametextBox1 = new System.Windows.Forms.TextBox();
            this.CheckindatetextBox4 = new System.Windows.Forms.TextBox();
            this.MfgdatetextBox3 = new System.Windows.Forms.TextBox();
            this.ExpdatetextBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ProductTypetextBox = new System.Windows.Forms.TextBox();
            this.ShowButton = new System.Windows.Forms.Button();
            this.RequestedQuantitytextBox5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Savebutton = new System.Windows.Forms.Button();
            this.SalespricetextBox4 = new System.Windows.Forms.TextBox();
            this.QuantityTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(30, 498);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(730, 245);
            this.dataGridView1.TabIndex = 81;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // ShowallButton
            // 
            this.ShowallButton.Location = new System.Drawing.Point(685, 460);
            this.ShowallButton.Name = "ShowallButton";
            this.ShowallButton.Size = new System.Drawing.Size(75, 23);
            this.ShowallButton.TabIndex = 80;
            this.ShowallButton.Text = "Show All";
            this.ShowallButton.UseVisualStyleBackColor = true;
            this.ShowallButton.Click += new System.EventHandler(this.ShowallButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.BranchIDlabel13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.BranchcomboBox1);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.ProductnametextBox1);
            this.groupBox1.Controls.Add(this.CheckindatetextBox4);
            this.groupBox1.Controls.Add(this.MfgdatetextBox3);
            this.groupBox1.Controls.Add(this.ExpdatetextBox2);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.ProductTypetextBox);
            this.groupBox1.Controls.Add(this.ShowButton);
            this.groupBox1.Controls.Add(this.RequestedQuantitytextBox5);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.Savebutton);
            this.groupBox1.Controls.Add(this.SalespricetextBox4);
            this.groupBox1.Controls.Add(this.QuantityTextBox);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(635, 454);
            this.groupBox1.TabIndex = 82;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(508, 49);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 101;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(427, 52);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(75, 21);
            this.checkBox1.TabIndex = 100;
            this.checkBox1.Text = "Search";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // BranchIDlabel13
            // 
            this.BranchIDlabel13.AutoSize = true;
            this.BranchIDlabel13.Location = new System.Drawing.Point(125, 28);
            this.BranchIDlabel13.Name = "BranchIDlabel13";
            this.BranchIDlabel13.Size = new System.Drawing.Size(94, 17);
            this.BranchIDlabel13.TabIndex = 74;
            this.BranchIDlabel13.Text = "Branch Name";
            this.BranchIDlabel13.Click += new System.EventHandler(this.BranchIDlabel13_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(132, 28);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 17);
            this.label12.TabIndex = 73;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(125, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 17);
            this.label8.TabIndex = 72;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // BranchcomboBox1
            // 
            this.BranchcomboBox1.FormattingEnabled = true;
            this.BranchcomboBox1.Location = new System.Drawing.Point(128, 25);
            this.BranchcomboBox1.Name = "BranchcomboBox1";
            this.BranchcomboBox1.Size = new System.Drawing.Size(121, 24);
            this.BranchcomboBox1.TabIndex = 71;
            this.BranchcomboBox1.SelectedIndexChanged += new System.EventHandler(this.BranchcomboBox1_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(108, 68);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 17);
            this.label10.TabIndex = 70;
            this.label10.Text = "Product Name";
            // 
            // ProductnametextBox1
            // 
            this.ProductnametextBox1.Location = new System.Drawing.Point(237, 68);
            this.ProductnametextBox1.Name = "ProductnametextBox1";
            this.ProductnametextBox1.Size = new System.Drawing.Size(100, 22);
            this.ProductnametextBox1.TabIndex = 69;
            // 
            // CheckindatetextBox4
            // 
            this.CheckindatetextBox4.Location = new System.Drawing.Point(237, 351);
            this.CheckindatetextBox4.Name = "CheckindatetextBox4";
            this.CheckindatetextBox4.Size = new System.Drawing.Size(100, 22);
            this.CheckindatetextBox4.TabIndex = 68;
            // 
            // MfgdatetextBox3
            // 
            this.MfgdatetextBox3.Location = new System.Drawing.Point(237, 301);
            this.MfgdatetextBox3.Name = "MfgdatetextBox3";
            this.MfgdatetextBox3.Size = new System.Drawing.Size(100, 22);
            this.MfgdatetextBox3.TabIndex = 67;
            // 
            // ExpdatetextBox2
            // 
            this.ExpdatetextBox2.Location = new System.Drawing.Point(237, 256);
            this.ExpdatetextBox2.Name = "ExpdatetextBox2";
            this.ExpdatetextBox2.Size = new System.Drawing.Size(100, 22);
            this.ExpdatetextBox2.TabIndex = 66;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(108, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 17);
            this.label2.TabIndex = 65;
            this.label2.Text = "Type";
            // 
            // ProductTypetextBox
            // 
            this.ProductTypetextBox.Location = new System.Drawing.Point(237, 111);
            this.ProductTypetextBox.Name = "ProductTypetextBox";
            this.ProductTypetextBox.Size = new System.Drawing.Size(100, 22);
            this.ProductTypetextBox.TabIndex = 64;
            // 
            // ShowButton
            // 
            this.ShowButton.Location = new System.Drawing.Point(560, 79);
            this.ShowButton.Name = "ShowButton";
            this.ShowButton.Size = new System.Drawing.Size(75, 23);
            this.ShowButton.TabIndex = 62;
            this.ShowButton.Text = "Load";
            this.ShowButton.UseVisualStyleBackColor = true;
            this.ShowButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // RequestedQuantitytextBox5
            // 
            this.RequestedQuantitytextBox5.Location = new System.Drawing.Point(237, 400);
            this.RequestedQuantitytextBox5.Name = "RequestedQuantitytextBox5";
            this.RequestedQuantitytextBox5.Size = new System.Drawing.Size(100, 22);
            this.RequestedQuantitytextBox5.TabIndex = 60;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(63, 405);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 17);
            this.label5.TabIndex = 59;
            this.label5.Text = "Requested Quantity";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(28, 28);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 17);
            this.label11.TabIndex = 58;
            this.label11.Text = "Branch Name";
            this.label11.Click += new System.EventHandler(this.label11_Click_1);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(101, 354);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 17);
            this.label9.TabIndex = 56;
            this.label9.Text = "Check In Date";
            // 
            // Savebutton
            // 
            this.Savebutton.Location = new System.Drawing.Point(554, 394);
            this.Savebutton.Name = "Savebutton";
            this.Savebutton.Size = new System.Drawing.Size(75, 28);
            this.Savebutton.TabIndex = 55;
            this.Savebutton.Text = "Save";
            this.Savebutton.UseVisualStyleBackColor = true;
            this.Savebutton.Click += new System.EventHandler(this.Savebutton_Click);
            // 
            // SalespricetextBox4
            // 
            this.SalespricetextBox4.Location = new System.Drawing.Point(237, 202);
            this.SalespricetextBox4.Name = "SalespricetextBox4";
            this.SalespricetextBox4.Size = new System.Drawing.Size(100, 22);
            this.SalespricetextBox4.TabIndex = 52;
            // 
            // QuantityTextBox
            // 
            this.QuantityTextBox.Location = new System.Drawing.Point(237, 158);
            this.QuantityTextBox.Name = "QuantityTextBox";
            this.QuantityTextBox.Size = new System.Drawing.Size(100, 22);
            this.QuantityTextBox.TabIndex = 51;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(108, 301);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 17);
            this.label7.TabIndex = 50;
            this.label7.Text = "MFG date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(108, 256);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 17);
            this.label6.TabIndex = 49;
            this.label6.Text = "Exp date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(108, 207);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 17);
            this.label4.TabIndex = 48;
            this.label4.Text = "Sales Price";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(108, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 17);
            this.label3.TabIndex = 47;
            this.label3.Text = "Quantity";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(561, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 17);
            this.label1.TabIndex = 46;
            this.label1.Text = "Product ID";
            // 
            // Branch_Inventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(786, 746);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.ShowallButton);
            this.Name = "Branch_Inventory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Branch_Inventory";
            this.Load += new System.EventHandler(this.Branch_Inventory_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button ShowallButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ProductTypetextBox;
        private System.Windows.Forms.Button ShowButton;
        private System.Windows.Forms.TextBox RequestedQuantitytextBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button Savebutton;
        private System.Windows.Forms.TextBox SalespricetextBox4;
        private System.Windows.Forms.TextBox QuantityTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox CheckindatetextBox4;
        private System.Windows.Forms.TextBox MfgdatetextBox3;
        private System.Windows.Forms.TextBox ExpdatetextBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox ProductnametextBox1;
        private System.Windows.Forms.ComboBox BranchcomboBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label BranchIDlabel13;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}