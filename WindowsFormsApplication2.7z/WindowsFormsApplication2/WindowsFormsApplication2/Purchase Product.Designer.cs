﻿namespace WindowsFormsApplication2
{
    partial class Purchase_Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.purchasepricetextBox13 = new System.Windows.Forms.TextBox();
            this.supplieridtextBox12 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.purchaseddatetextBox8 = new System.Windows.Forms.TextBox();
            this.mfgdatetextBox7 = new System.Windows.Forms.TextBox();
            this.expdatetextBox6 = new System.Windows.Forms.TextBox();
            this.pnametextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.producttypetextBox2 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.savebutton1 = new System.Windows.Forms.Button();
            this.salespricetextBox4 = new System.Windows.Forms.TextBox();
            this.quantitytextBox3 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.showallproducinfo = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.purchasepricetextBox13);
            this.groupBox1.Controls.Add(this.supplieridtextBox12);
            this.groupBox1.Controls.Add(this.textBox9);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.textBox10);
            this.groupBox1.Controls.Add(this.textBox11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.purchaseddatetextBox8);
            this.groupBox1.Controls.Add(this.mfgdatetextBox7);
            this.groupBox1.Controls.Add(this.expdatetextBox6);
            this.groupBox1.Controls.Add(this.pnametextBox);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.producttypetextBox2);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.savebutton1);
            this.groupBox1.Controls.Add(this.salespricetextBox4);
            this.groupBox1.Controls.Add(this.quantitytextBox3);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(605, 441);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(397, 35);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(75, 21);
            this.checkBox1.TabIndex = 99;
            this.checkBox1.Text = "Search";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(478, 32);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 98;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // purchasepricetextBox13
            // 
            this.purchasepricetextBox13.Location = new System.Drawing.Point(206, 207);
            this.purchasepricetextBox13.Name = "purchasepricetextBox13";
            this.purchasepricetextBox13.Size = new System.Drawing.Size(100, 22);
            this.purchasepricetextBox13.TabIndex = 97;
            this.purchasepricetextBox13.TextChanged += new System.EventHandler(this.purchasepricetextBox13_TextChanged);
            // 
            // supplieridtextBox12
            // 
            this.supplieridtextBox12.Location = new System.Drawing.Point(206, 129);
            this.supplieridtextBox12.Name = "supplieridtextBox12";
            this.supplieridtextBox12.Size = new System.Drawing.Size(100, 22);
            this.supplieridtextBox12.TabIndex = 96;
            this.supplieridtextBox12.TextChanged += new System.EventHandler(this.supplieridtextBox12_TextChanged);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(615, 171);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 22);
            this.textBox9.TabIndex = 95;
            this.textBox9.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(67, 129);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 17);
            this.label5.TabIndex = 94;
            this.label5.Text = "Supplier ID";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(615, 124);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 22);
            this.textBox10.TabIndex = 93;
            this.textBox10.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(615, 67);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 22);
            this.textBox11.TabIndex = 92;
            this.textBox11.TextChanged += new System.EventHandler(this.textBox11_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(67, 171);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 17);
            this.label10.TabIndex = 91;
            this.label10.Text = "Product Type";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(69, 83);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(98, 17);
            this.label12.TabIndex = 90;
            this.label12.Text = "Product Name";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // purchaseddatetextBox8
            // 
            this.purchaseddatetextBox8.Location = new System.Drawing.Point(206, 403);
            this.purchaseddatetextBox8.Name = "purchaseddatetextBox8";
            this.purchaseddatetextBox8.Size = new System.Drawing.Size(100, 22);
            this.purchaseddatetextBox8.TabIndex = 89;
            this.purchaseddatetextBox8.TextChanged += new System.EventHandler(this.purchaseddatetextBox8_TextChanged);
            // 
            // mfgdatetextBox7
            // 
            this.mfgdatetextBox7.Location = new System.Drawing.Point(206, 360);
            this.mfgdatetextBox7.Name = "mfgdatetextBox7";
            this.mfgdatetextBox7.Size = new System.Drawing.Size(100, 22);
            this.mfgdatetextBox7.TabIndex = 88;
            this.mfgdatetextBox7.TextChanged += new System.EventHandler(this.mfgdatetextBox7_TextChanged);
            // 
            // expdatetextBox6
            // 
            this.expdatetextBox6.Location = new System.Drawing.Point(206, 316);
            this.expdatetextBox6.Name = "expdatetextBox6";
            this.expdatetextBox6.Size = new System.Drawing.Size(100, 22);
            this.expdatetextBox6.TabIndex = 87;
            this.expdatetextBox6.TextChanged += new System.EventHandler(this.expdatetextBox6_TextChanged);
            // 
            // pnametextBox
            // 
            this.pnametextBox.Location = new System.Drawing.Point(206, 83);
            this.pnametextBox.Name = "pnametextBox";
            this.pnametextBox.Size = new System.Drawing.Size(100, 22);
            this.pnametextBox.TabIndex = 86;
            this.pnametextBox.TextChanged += new System.EventHandler(this.pnametextBox_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(69, 212);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 17);
            this.label8.TabIndex = 85;
            this.label8.Text = "Purchase Price";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // producttypetextBox2
            // 
            this.producttypetextBox2.Location = new System.Drawing.Point(206, 168);
            this.producttypetextBox2.Name = "producttypetextBox2";
            this.producttypetextBox2.Size = new System.Drawing.Size(100, 22);
            this.producttypetextBox2.TabIndex = 83;
            this.producttypetextBox2.TextChanged += new System.EventHandler(this.producttypetextBox2_TextChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(478, 62);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(121, 23);
            this.button2.TabIndex = 81;
            this.button2.Text = "Load";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(17, 32);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 17);
            this.label11.TabIndex = 80;
            this.label11.Text = "HQ";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(63, 406);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 17);
            this.label9.TabIndex = 78;
            this.label9.Text = "Purchased Date";
            this.label9.Click += new System.EventHandler(this.label9_Click_1);
            // 
            // savebutton1
            // 
            this.savebutton1.Location = new System.Drawing.Point(506, 412);
            this.savebutton1.Name = "savebutton1";
            this.savebutton1.Size = new System.Drawing.Size(75, 23);
            this.savebutton1.TabIndex = 77;
            this.savebutton1.Text = "Save";
            this.savebutton1.UseVisualStyleBackColor = true;
            this.savebutton1.Click += new System.EventHandler(this.button1_Click);
            // 
            // salespricetextBox4
            // 
            this.salespricetextBox4.Location = new System.Drawing.Point(206, 277);
            this.salespricetextBox4.Name = "salespricetextBox4";
            this.salespricetextBox4.Size = new System.Drawing.Size(100, 22);
            this.salespricetextBox4.TabIndex = 74;
            this.salespricetextBox4.TextChanged += new System.EventHandler(this.salespricetextBox4_TextChanged);
            // 
            // quantitytextBox3
            // 
            this.quantitytextBox3.Location = new System.Drawing.Point(206, 246);
            this.quantitytextBox3.Name = "quantitytextBox3";
            this.quantitytextBox3.Size = new System.Drawing.Size(100, 22);
            this.quantitytextBox3.TabIndex = 73;
            this.quantitytextBox3.TextChanged += new System.EventHandler(this.quantitytextBox3_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(69, 365);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 17);
            this.label7.TabIndex = 72;
            this.label7.Text = "MFG date";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(67, 316);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 17);
            this.label6.TabIndex = 71;
            this.label6.Text = "Exp date";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(69, 277);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 17);
            this.label4.TabIndex = 70;
            this.label4.Text = "Sales Price";
            this.label4.Click += new System.EventHandler(this.label4_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(69, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 17);
            this.label3.TabIndex = 69;
            this.label3.Text = "Quantity";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(521, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 17);
            this.label1.TabIndex = 68;
            this.label1.Text = "Product ID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // showallproducinfo
            // 
            this.showallproducinfo.Location = new System.Drawing.Point(658, 454);
            this.showallproducinfo.Name = "showallproducinfo";
            this.showallproducinfo.Size = new System.Drawing.Size(75, 23);
            this.showallproducinfo.TabIndex = 78;
            this.showallproducinfo.Text = "Show All";
            this.showallproducinfo.UseVisualStyleBackColor = true;
            this.showallproducinfo.Click += new System.EventHandler(this.button3_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 494);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(721, 208);
            this.dataGridView1.TabIndex = 79;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Purchase_Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(762, 710);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.showallproducinfo);
            this.Controls.Add(this.groupBox1);
            this.Name = "Purchase_Product";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Purchase_Product";
            this.Load += new System.EventHandler(this.Purchase_Product_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox producttypetextBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button savebutton1;
        private System.Windows.Forms.TextBox salespricetextBox4;
        private System.Windows.Forms.TextBox quantitytextBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button showallproducinfo;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox purchaseddatetextBox8;
        private System.Windows.Forms.TextBox mfgdatetextBox7;
        private System.Windows.Forms.TextBox expdatetextBox6;
        private System.Windows.Forms.TextBox pnametextBox;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox purchasepricetextBox13;
        private System.Windows.Forms.TextBox supplieridtextBox12;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.CheckBox checkBox1;


    }
}