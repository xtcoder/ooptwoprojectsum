﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class SalesForm : Form

    {
        int Rowcount = 0;
        public SalesForm()
        {
            InitializeComponent();
        }

        private void Remove_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add();
            dataGridView1.Rows[Rowcount].Cells[0].Value = textBox1.Text;
            dataGridView1.Rows[Rowcount].Cells[1].Value = textBox2.Text;
            dataGridView1.Rows[Rowcount].Cells[2].Value = textBox3.Text;
            dataGridView1.Rows[Rowcount].Cells[3].Value = textBox4.Text;
            //dataGridView1.Rows[Rowcount].Cells[4].Value = textBox1.Text;
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            //T5.Text = "";

            Rowcount++;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
