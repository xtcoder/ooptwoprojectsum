﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication2
{
    class Sales
    {

        private int sales_Serial;

        public int Sales_Serial
        {
            get { return sales_Serial; }
            set { sales_Serial = value; }
        } 
        private DateTime salesdate;

        public DateTime Salesdate
        {
            get { return salesdate; }
            set { salesdate = value; }
        }
        private int sales_by_empid;

        public int Sales_by_Empid
        {
            get { return sales_by_empid; }
            set { sales_by_empid = value; }
        }
        private int quantity;

        public int Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }
        private int branchid;

        public int Branchid
        {
            get { return branchid; }
            set { branchid = value; }
        }
        private int price_Per_Unit;

        public int Price_Per_Unit
        {
            get { return price_Per_Unit; }
            set { price_Per_Unit = value; }
        }

    }
}
