﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Employee p = new Employee();
            string ename = textBox1.Text;
            string epassword = textBox2.Text;
            string eaddress = textBox3.Text;
            string a=p.createnewuser(ename, epassword, eaddress);
            int s2 = Convert.ToInt32(a);
            
            string s1 = p.getpassword(s2);
            MessageBox.Show("Your ID is "+a+ "and password is "+s1);
        }
    }
}
