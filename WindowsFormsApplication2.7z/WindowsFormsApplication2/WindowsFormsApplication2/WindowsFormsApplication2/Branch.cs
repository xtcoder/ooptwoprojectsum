﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace WindowsFormsApplication2
{
    class Branch
    {
        private string branchname;

        public string Branchname
        {
            get { return branchname; }
            set { branchname = value; }
        }
        private string branchid;

        public string Branchid
        {
            get { return branchid; }
            set { branchid = value; }
        }
        private Product branchinventory;

        public Product Branchinventory
        {
            get { return branchinventory; }
            set { branchinventory = value; }
        }
        private Employee branchEmployee;

        private Employee BranchEmployee
        {
            get { return branchEmployee; }
            set { branchEmployee = value; }
        } 
    }
}
