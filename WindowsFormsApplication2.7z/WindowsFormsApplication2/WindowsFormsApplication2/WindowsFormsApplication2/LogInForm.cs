﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

                    
            }

        private void button2_Click(object sender, EventArgs e)
        {

            if (textBox1.Text.Trim() == "")
            {
                MessageBox.Show("Please Type your Username");
            }
            else if (textBox2.Text.Trim() == "")
            {
                MessageBox.Show("Please Type Your Password");
            }
            else
            {
                int id = Convert.ToInt32(textBox1.Text);
                string password = textBox2.Text.Trim().ToString();
                Employee q = new Employee();
                bool funcp = q.Loginidandpassword(id, password);

                if (funcp == true)
                {
                    Employee q1 = new Employee();
                    string username = q1.getusername(id);
                    //MessageBox.Show("Your Login is Successful. Welcome MR. " + username + ".");
                    Form1 obj1 = new Form1(id);
                    obj1.Show();
                    this.Hide();

                }
                else if (funcp == false)
                {

                    MessageBox.Show("Invalid username or password");

                }
        }
        }



        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }
    }
}
