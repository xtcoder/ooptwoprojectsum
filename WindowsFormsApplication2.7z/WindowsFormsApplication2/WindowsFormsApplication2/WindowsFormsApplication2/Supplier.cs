﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication2
{
    class Supplier
    {
        private int supplierId;

        public int SupplierId
        {
            get { return supplierId; }
            set { supplierId = value; }
        }
        private string supplierp_P_Type;

        public string Supplier_P_Type
        {
            get { return supplierp_P_Type; }
            set { supplierp_P_Type = value; }
        }
        private int supplierPhone;

        public int SupplierPhone
        {
            get { return supplierPhone; }
            set { supplierPhone = value; }
        }
        private string supplierAddress;

        public string SupplierAddress
        {
            get { return supplierAddress; }
            set { supplierAddress = value; }
        }
        

    }
}
