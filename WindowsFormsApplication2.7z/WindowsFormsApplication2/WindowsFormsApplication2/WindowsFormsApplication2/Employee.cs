﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace WindowsFormsApplication2
{
    class Employee
    {
        private int empid;

        public int Empid
        {
            get { return empid; }
            set { empid = value; }
        }
        private string empname;


        public string Empname
        {
            get { return empname; }
            set { empname = value; }
        }
        private string password;

        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        private string type;

        public string Type
        {
            get { return type; }
            set { type = value; }
        }
        private int salary;

        public int Salary
        {
            get { return salary; }
            set { salary = value; }
        }
        private string address;

        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        private string branch;

        public string Branch
        {
            get { return branch; }
            set { branch = value; }
        }
        private int deptno;

        public int Deptno
        {
            get { return deptno; }
            set { deptno = value; }
        }

        public bool Save()
        {
            string sql = "SELECT * FROM emp WHERE empno=" + this.Empid;
            DataTable dt = DataAccess.GetDataTable(sql);
            if (dt.Rows.Count > 0)
            {
                sql = "UPDATE emp SET Emp_Name='" + this.Empname + "', Password=" + this.Password + ", Type=" + this.Type + "', Salary=" + this.Salary + "', Address=" + this.Address + "', Branch=" + this.Branch + "', Dept_NO=" + this.Deptno + " WHERE Emp_ID=" + this.Empid;
                DataAccess.ExecuteSQL(sql);
                return true;
            }
            else
            {

                sql = "INSERT INTO emp (Emp_Name,Password, Type,Salary,Address,Branch,Dept_NO) VALUES ('" + this.Empname + "'," + this.Password + "," + this.Type + this.Salary + "," + this.Address + "," + this.Branch + "," + this.Deptno + ")";
                DataAccess.ExecuteSQL(sql);
                return true;
            }
        }
        public string createnewuser(string ename,string epassword,string eaddress){
            //string sql = "INSERT INTO Employee (Emp_Name,Password, Address) VALUES ('" + ename + "'," + epassword + "," + eaddress +")";
            //string sql = "insert into Bus_Id (bus_id,Type,Bus_number) values('" + add_bus_textBox.Text + "','" + add_bus_textBox1.Text + "','" + add_bus_textBox2.Text + "')";
            string sql = "INSERT INTO Employee (Emp_Name,Password, Address) VALUES ('" + ename + "','" + epassword + "','" + eaddress +"')" ;
            DataAccess.ExecuteSQL(sql);
            //string sql = "select * from seat_number where bus_id='" + label3.Text + "' and Seat_number='A1'";
            string sql1 = "SELECT * FROM Employee WHERE Emp_Name='" + ename +"' and Password='"+epassword+"' and Address= "+eaddress;
            DataTable dt = DataAccess.GetDataTable(sql1);
            string a1=dt.Rows[0]["Emp_ID"].ToString();
            string a = a1.ToString();
            return a;
            
        
        }

        public bool Load(int empid)
        {
            string sql = "SELECT * FROM emp WHERE Emp_ID=" + empid;
            DataTable dt = DataAccess.GetDataTable(sql);

            if (dt.Rows.Count > 0)
            {
                this.Empid = empid;
                this.Empname = dt.Rows[0]["Emp_Name"].ToString();
                this.Password = dt.Rows[0]["Password"].ToString();
                this.Type = dt.Rows[0]["Type"].ToString();
                this.Salary = Convert.ToInt32(dt.Rows[0]["Salary"]);
                this.Address = dt.Rows[0]["Address"].ToString();
                this.Branch = dt.Rows[0]["Branch"].ToString();
                this.Deptno = Convert.ToInt32(dt.Rows[0]["deptno"]);
                return true;
            }
            else
            {
                this.Empid = -1;
                this.Empname = null;
                this.Password = null;
                this.Type = null;
                this.Salary = -1;
                this.Address = null;
                this.Branch = null;

                this.Deptno = -1;
                return false;
            }

        }
        public string getusername(int userid)
        {
            string sql = "select * from Employee where Emp_ID=" + userid;
            DataTable dt = DataAccess.GetDataTable(sql);
            string returnstring = dt.Rows[0]["Emp_Name"].ToString();
            return returnstring;
        }
        public string getaddress(int userid)
        {
            string sql = "select * from Employee where Emp_ID=" + userid;
            DataTable dt = DataAccess.GetDataTable(sql);
            string returnstring = dt.Rows[0]["Address"].ToString();
            return returnstring;
        }
        public string getbranchid(int userid)
        {
            string sql = "select * from Employee where Emp_ID=" + userid;
            DataTable dt = DataAccess.GetDataTable(sql);
            string returnstring = dt.Rows[0]["Branch_ID"].ToString();
            return returnstring;
        }
        public string getbranchname(int branchid)
        {
            string sql = " SELECT Branch_Name FROM Branch WHERE Branch_ID= " + branchid;
            DataTable dt = DataAccess.GetDataTable(sql);
            string returnstring = dt.Rows[0]["Branch_Name"].ToString();
            return returnstring;
        }
        public string getpassword(int userid)
        {
            string sql = "select * from Employee where Emp_ID=" + userid;
            DataTable dt = DataAccess.GetDataTable(sql);
            string returnstring = dt.Rows[0]["Password"].ToString();
            return returnstring;
        }
        public void updatefromform1(string aname, string aAddress,string  aPassword,int aEmpid){

            //string sql = "UPDATE Employee SET Emp_Name='" + aname+ "', Password=" + aPassword + ", Address=" + aAddress + " WHERE Emp_ID=" + aEmpid;
            string sql = "UPDATE Employee SET Emp_Name= '" + aname + "' WHERE Emp_ID=" + aEmpid;
            DataAccess.ExecuteSQL(sql);
            string sql1 = "UPDATE Employee SET Address= '" + aAddress + "' WHERE Emp_ID=" + aEmpid;
            DataAccess.ExecuteSQL(sql1);
            string sql2 = "UPDATE Employee SET Password= '" + aPassword + "' WHERE Emp_ID=" + aEmpid;
            DataAccess.ExecuteSQL(sql2);
            
            
        
        }


        public bool Loginidandpassword(int userid, string password)
        {

            string sql = "select  *  from Employee where Emp_ID=" + userid + " and password = '" + password + "'";

            DataTable dt = DataAccess.GetDataTable(sql);
            if (dt.Rows.Count == 0)
            {
                return false;
            }

            else
            {
                return true;

            }
        }
        public string typecheck(int userid)
        {
            string sql = "select * from Employee where Emp_ID=" + userid;
            DataTable dt = DataAccess.GetDataTable(sql);
            string returnstring = dt.Rows[0]["Type"].ToString();
            return returnstring;

        }
       

      
    }
}
