﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication2
{
    class Product
    {
        private DateTime expDate;

        public DateTime ExpDate
        {
            get { return expDate; }
            set { expDate = value; }
        }
        private DateTime mfgDate;

        public DateTime MfgDate
        {
            get { return mfgDate; }
            set { mfgDate = value; }
        }

        private Supplier sinfo;

        public Supplier Sinfo
        {
            get { return sinfo; }
            set { sinfo = value; }
        }
        private DateTime purchaseDate;

        public DateTime PurchaseDate
        {
            get { return purchaseDate; }
            set { purchaseDate = value; }
        }
        private DateTime salesDate;

        public DateTime SalesDate
        {
            get { return salesDate; }
            set { salesDate = value; }
        }
        private int productid;

        public int Productid
        {
            get { return productid; }
            set { productid = value; }
        }
    }
}
