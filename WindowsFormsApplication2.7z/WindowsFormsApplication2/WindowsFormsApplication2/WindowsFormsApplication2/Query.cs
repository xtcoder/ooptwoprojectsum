﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace WindowsFormsApplication2
{
    class Query
    {
       // private int count;
        //private DataTable dt;
        //public DataTable LoadedTable
        //{
        //    get { return this.dt; }

        //}

        public bool Loginidandpassword(int userid, string password)
        {

            string sql = "select  *  from Employee where Emp_ID=" + userid + " and password = '" + password + "'";

            DataTable dt = DataAccess.GetDataTable(sql);
            if (dt.Rows.Count == 0)
            {
                return false;
            }

            else
            {
                return true;

            }
        }
        public string typecheck(int userid) {
            string sql = "select * from Employee where Emp_ID=" + userid;
            DataTable dt = DataAccess.GetDataTable(sql);
            string returnstring = dt.Rows[0]["Type"].ToString();
            return returnstring;
        
        }
        public string getusername(int userid) {
            string sql = "select * from Employee where Emp_ID=" + userid;
            DataTable dt = DataAccess.GetDataTable(sql);
            string returnstring = dt.Rows[0]["Emp_Name"].ToString();
            return returnstring;
        
        
        }
    }
}
